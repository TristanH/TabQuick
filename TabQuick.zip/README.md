TabQuick
========
Now functional! Although not perfect..

A chrome extension which helps you save your current tabs effortlessly, whenever you want.

I got sick of having 15 tabs open related to one subject and not being able to save them easily.
With TabQuick, you just click the icon, and it puts every tab you have open into a bookmark folder, to be accessed later with no problem. 
It's especially useful if, say, you have 20 tabs open related to school work and you want to come back to them after an hour of procrastination without leaving them all open.

Future updates:
-Clean up code, add more comments

